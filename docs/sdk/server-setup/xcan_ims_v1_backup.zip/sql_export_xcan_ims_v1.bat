@echo off
set errorlevel=0

chcp 65001
chcp 936

echo %cd%
cd /d %~dp0

set user_name=root
set user_pass=123456

set bat_name=%~n0
set db_name=%bat_name:~11%

set date_str=%date:~0,4%%date:~5,2%%date:~8,2%
set time_str=%time: =0%
set time_str=%time_str::=%
set time_str=%time_str:~0,6%

set sql=%db_name%.%date_str%-%time_str%.full.sql

echo.
echo export database %db_name% to ddl: %ddl% 
mysqldump -u%user_name% -p%user_pass% --max_allowed_packet=512m --add-drop-database --hex-blob --default-character-set=utf8mb4 -R --events --triggers --single-transaction -B %db_name%  > %sql%

echo.
echo exporting ...
echo.
ping -n 2 127.0.0.1 >nul
echo success!
echo.

EndLocal
echo Press any key to exit ...
pause
exit
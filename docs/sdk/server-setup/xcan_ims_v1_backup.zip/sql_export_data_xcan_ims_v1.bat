@echo off
set errorlevel=0

chcp 65001
chcp 936

echo %cd%
cd /d %~dp0

set user_name=root
set user_pass=123456

set bat_name=%~n0
set db_name=%bat_name:~16%

set date_str=%date:~0,4%%date:~5,2%%date:~8,2%
set time_str=%time: =0%
set time_str=%time_str::=%
set time_str=%time_str:~0,6%
set sql_file=%db_name%.%date_str%-%time_str%.data.sql

echo.
echo export database %db_name% to sql_file: %sql_file% 
rem ..\mysql_v4\bin\mysqldump -u%user_name% -p%user_pass% --max_allowed_packet=102400 --hex-blob --extended-insert=true --default-character-set=utf8 --single-transaction --insert-ignore -t -n -c -B %db_name% > %sql_file%
mysqldump -u%user_name% -p%user_pass% --max_allowed_packet=512m --hex-blob --extended-insert=true --default-character-set=utf8mb4 --single-transaction --replace -t -n -c -B %db_name% > %sql_file%

echo.
echo exporting ...
echo.
ping -n 2 127.0.0.1 >nul
echo success!
echo.

EndLocal
echo Press any key to exit ...
pause
exit
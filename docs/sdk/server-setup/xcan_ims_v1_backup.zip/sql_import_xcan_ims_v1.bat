@echo off
set errorlevel=0

chcp 65001
chcp 936

cd /d %~dp0

set user_name=root
set user_pass=123456

set bat_name=%~n0
set db_name=%bat_name:~11%

echo.&set /p file=������Ҫ��װ��sql�ļ���
call :do %file%
:do
set sql_file=%1

echo.
echo create database %db_name% if not exists!

::mysql -u%user_name% -p%user_pass% --default-character-set=utf8mb4 -e "grant all privileges on *.* to root@'%' identified by '.';flush privileges;"

echo.
echo importing ...
mysql -u%user_name% -p%user_pass% --default-character-set=utf8mb4 -e "create database if not exists %db_name% default character set utf8mb4 collate utf8mb4_general_ci"

mysql -u%user_name% -p%user_pass% --default-character-set=utf8mb4 %db_name% < %sql_file%

echo.
echo imported !!!
echo.
ping -n 3 127.0.0.1 >nul
echo success!

echo.

EndLocal
echo Press any key to exit ...
pause
exit